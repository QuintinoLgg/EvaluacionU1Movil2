# Soap Sample
A sample/demo app that requests XML response data from a web service (http://www.webserviceX.NET) and its WSDL file (http://www.webservicex.net/globalweather.asmx?WSDL), and displays extracted data (major cities for a certain country) based on user input.

![alt tag](https://media.giphy.com/media/26FmQkLBVBzUCkHXa/giphy.gif)

# Donation

*Curious for more? Spare me a coffee to support what I do today:* 

<a href="https://www.buymeacoffee.com/DaveNOTDavid" target="_blank"><img src="https://www.buymeacoffee.com/assets/img/custom_images/orange_img.png" alt="Buy Me A Coffee" style="height: 41px !important;width: 174px !important;box-shadow: 0px 3px 2px 0px rgba(190, 190, 190, 0.5) !important;-webkit-box-shadow: 0px 3px 2px 0px rgba(190, 190, 190, 0.5) !important;" ></a>
