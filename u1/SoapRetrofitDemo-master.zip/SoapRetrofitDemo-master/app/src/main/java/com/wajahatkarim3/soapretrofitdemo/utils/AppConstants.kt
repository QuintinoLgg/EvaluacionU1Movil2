package com.wajahatkarim3.soapretrofitdemo.utils

object AppConstants {

    object HTTP
    {
        val BASE_URL = "http://www.holidaywebservice.com/HolidayService_v2/HolidayService2.asmx/"
    }
}