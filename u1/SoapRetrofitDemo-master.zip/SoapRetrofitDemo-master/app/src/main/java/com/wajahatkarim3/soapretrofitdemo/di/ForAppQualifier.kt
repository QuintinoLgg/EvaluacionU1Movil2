package com.wajahatkarim3.soapretrofitdemo.di

import javax.inject.Qualifier

@Qualifier
@Retention(AnnotationRetention.RUNTIME)
annotation class ForAppQualifier